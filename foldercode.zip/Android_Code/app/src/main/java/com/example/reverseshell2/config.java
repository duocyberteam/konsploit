package com.example.reverseshell2;

public class config {
    public static String IP = "ip";
    public static String port = "port";
}